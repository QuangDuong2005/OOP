package controller;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import service.Accountservice;
import exception.DuplicateException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Staff;
import repository.StaffRepository;

// Controller màn hình cấp tài khoản mới cho nhân viên
public class CreateAccountController implements Initializable {

    // --- Bảng Nhân viên ---
    @FXML public TableView<Staff> tblStaff;
    @FXML public TableColumn<Staff, String> colID;
    @FXML public TableColumn<Staff, String> colName;
    @FXML public TableColumn<Staff, String> colPhone;
    @FXML public TableColumn<Staff, String> colStaffRole;

    // --- Form nhập liệu thông tin tài khoản ---
    @FXML public TextField txtSelectedStaff; // Hiển thị tên nhân viên đang chọn
    @FXML public TextField txtUsername;
    @FXML public ComboBox<String> cbRole;    // Chọn quyền (Manager/Sale/...)
    @FXML public Button btnCreate;
    @FXML public Button btnCancel;

    public Accountservice accountservice;
    public Staff selectedStaff = null; 

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        accountservice = new Accountservice();
        
        // 1. Cấu hình cột và tải dữ liệu nhân viên vào bảng
        setupTable();
        loadStaffData();

        // 2. Cấu hình ComboBox quyền hạn
        cbRole.getItems().addAll("Manager", "Sale", "Accountant");
        cbRole.getSelectionModel().select("Manager"); // Mặc định chọn Manager
        
        // 3. Lắng nghe sự kiện click chọn dòng trong bảng
        tblStaff.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                selectedStaff = newVal; // Lưu nhân viên được chọn
                // Hiển thị tên lên ô text để user biết mình đang chọn ai
                txtSelectedStaff.setText(newVal.getFullName() + " - " + newVal.getStaffID());
            }
        });
    }

    public void setupTable() {
        // Ánh xạ cột với tên thuộc tính trong class Staff
        colID.setCellValueFactory(new PropertyValueFactory<>("staffID"));
        colName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colStaffRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
    }

    public void loadStaffData() {
        // Lấy danh sách nhân viên từ file JSON
        List<Staff> list = StaffRepository.loadStaffsFromFile();
        ObservableList<Staff> observableList = FXCollections.observableArrayList(list);
        tblStaff.setItems(observableList);
    }

    // --- Xử lý nút "Tạo tài khoản" ---
    @FXML
    public void handleCreateAccount() {
        // 1. Validate: Kiểm tra đã chọn nhân viên từ bảng chưa
        if (selectedStaff == null) {
            showAlert(Alert.AlertType.ERROR, "Chưa chọn nhân viên", "Vui lòng chọn một nhân viên từ danh sách bên trái!");
            return;
        }

        // 2. Lấy dữ liệu nhập
        String username = txtUsername.getText().trim();
        String role = cbRole.getValue();

        if (username.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Thiếu thông tin", "Vui lòng nhập Tên đăng nhập.");
            return;
        }

        try {
            // 3. Gọi Service để tạo tài khoản và nhận về mật khẩu ngẫu nhiên
            String generatedPassword = accountservice.createAccount(username, role, selectedStaff.getStaffID());

            showPasswordDialog(username, generatedPassword);

            closeWindow();

        } catch (DuplicateException e) {
            showAlert(Alert.AlertType.ERROR, "Trùng lặp", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Lỗi hệ thống", e.getMessage());
        }
    }

    // Hàm hiển thị popup chứa Username & Password 
    public void showPasswordDialog(String user, String pass) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Tạo tài khoản thành công");
        alert.setHeaderText("Đã tạo tài khoản cho NV: " + selectedStaff.getFullName());
        TextArea textArea = new TextArea("Username: " + user + "\nPassword: " + pass);
        textArea.setEditable(false);
        textArea.setWrapText(true);
        textArea.setMaxWidth(Double.MAX_VALUE);
        textArea.setMaxHeight(Double.MAX_VALUE);

        alert.getDialogPane().setContent(textArea);
        alert.showAndWait();
    }

    @FXML
    public void handleCancel() {
        closeWindow();
    }

    public void closeWindow() {
        Stage stage = (Stage) btnCancel.getScene().getWindow();
        stage.close();
    }

    public void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}