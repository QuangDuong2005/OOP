package controller;

import service.Bookingservice;
import java.io.IOException;
import java.util.Optional;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Booking;
import util.UserSession;

// Controller quản lý danh sách Đơn đặt Tour (Booking)
public class BookingListController {

    // --- Khai báo các cột và bảng khớp với FXML ---
    @FXML public TableView<Booking> tableBooking;
    @FXML public TableColumn<Booking, String> colID;
    @FXML public TableColumn<Booking, String> colCusID;
    @FXML public TableColumn<Booking, String> colTourID;
    @FXML public TableColumn<Booking, Integer> colPeople;
    @FXML public TableColumn<Booking, Double> colTotal;
    @FXML public TableColumn<Booking, String> colStatus; 

    public Bookingservice bookingservice;
    public ObservableList<Booking> bookingList;
    
    public String currentStaffId; // ID nhân viên đang thao tác

    public void initialize() {
        bookingservice = new Bookingservice();
        bookingList = FXCollections.observableArrayList();

        // 1. Lấy thông tin User đang đăng nhập từ Session (để ghi log ai tạo đơn)
        if (UserSession.getSession() != null) {
            this.currentStaffId = UserSession.getSession().getAccount().getUsername(); 
        } else {
            this.currentStaffId = "UNKNOWN"; 
        }
        
        // 2. Cấu hình hiển thị dữ liệu cho các cột
        colID.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getBookingID()));
        colCusID.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getCustomerID()));
        colTourID.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getTourID()));
        colPeople.setCellValueFactory(cell -> new SimpleObjectProperty<>(cell.getValue().getNumberOfPeople()));
        colTotal.setCellValueFactory(cell -> new SimpleObjectProperty<>(cell.getValue().getTotalAmount()));
        
        // Cột trạng thái
        colStatus.setCellValueFactory(cell -> {
            boolean isCancel = cell.getValue().getIsCancelled(); 
            return new SimpleStringProperty(isCancel ? "Đã gửi Hủy/Chờ duyệt" : "Đã đặt");
        });

        tableBooking.setItems(bookingList);
        loadData();
    }

    // --- Hàm tải dữ liệu từ Service lên bảng ---
    public void loadData() {
        try {
             bookingList.setAll(bookingservice.getBookings());
             tableBooking.refresh(); 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void handleAdd(ActionEvent event) {
        showDialog(null); 
    }

    @FXML
    void handleEdit(ActionEvent event) {
        Booking selected = tableBooking.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Thông báo", "Vui lòng chọn đơn hàng để sửa", Alert.AlertType.WARNING);
            return;
        }
        // Validate: Không cho sửa đơn đang chờ hủy
        if (selected.getIsCancelled()) {
            showAlert("Cảnh báo", "Đơn hàng này đang chờ hủy, không thể sửa!", Alert.AlertType.ERROR);
            return;
        }
        showDialog(selected); 
    }

    // --- XỬ LÝ GỬI YÊU CẦU HỦY (Cần Manager duyệt) ---
    @FXML
    void handleCancelRequest(ActionEvent event) {
        Booking selected = tableBooking.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Thông báo", "Vui lòng chọn đơn hàng cần hủy", Alert.AlertType.WARNING);
            return;
        }
        
        if (selected.getIsCancelled()) {
            showAlert("Thông báo", "Đơn này đã được gửi yêu cầu hủy trước đó.", Alert.AlertType.INFORMATION);
            return;
        }

        // 1. Hiển thị hộp thoại nhập lý do hủy
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Yêu cầu hủy Booking");
        dialog.setHeaderText("Gửi yêu cầu hủy cho Quản lý");
        dialog.setContentText("Nhập lý do hủy:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(reason -> {
            if (reason.trim().isEmpty()) {
                showAlert("Lỗi", "Phải nhập lý do để quản lý duyệt!", Alert.AlertType.ERROR);
                return;
            }

            try {
                // 2. Gọi Service xử lý logic (Gửi request Pending)
                bookingservice.cancelBooking(selected.getBookingID(), selected.getTourID(), reason);
                
                showAlert("Thành công", "Đã gửi yêu cầu hủy thành công!", Alert.AlertType.INFORMATION);
                loadData(); // Refresh lại bảng để cập nhật trạng thái
                
            } catch (IllegalStateException e) {
                showAlert("Không thể hủy", e.getMessage(), Alert.AlertType.ERROR);
            } catch (Exception e) {
                e.printStackTrace();
                showAlert("Lỗi hệ thống", e.getMessage(), Alert.AlertType.ERROR);
            }
        });
    }

    // --- Hàm tiện ích: Mở cửa sổ popup  ---
    public void showDialog(Booking booking) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/BookingDialog.fxml"));
            Parent root = loader.load();
            
            // Lấy controller con để truyền dữ liệu sang
            BookingDialogController dialogservice = loader.getController();
            dialogservice.setBookingservice(bookingservice);
            dialogservice.setCurrentStaffId(currentStaffId);
            
            // Nếu là sửa, truyền dữ liệu cũ vào form
            if (booking != null) {
                dialogservice.setEditData(booking);
            }

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL); // Chặn cửa sổ chính khi đang mở popup
            stage.setTitle(booking == null ? "Tạo Booking Mới" : "Cập Nhật Booking");
            stage.setScene(new Scene(root));
            stage.showAndWait(); 
            
            loadData(); 
            
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Lỗi", "Không thể mở form nhập liệu: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    public void showAlert(String title, String content, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}