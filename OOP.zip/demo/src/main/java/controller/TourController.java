package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Tour;
import repository.TourRepository;

// Controller quản lý màn hình danh sách Tour
public class TourController implements Initializable {

    @FXML public TableView<Tour> tourTable;
    
    // --- Khai báo các cột khớp với fx:id trong FXML ---
    @FXML public TableColumn<Tour, String> colId;
    @FXML public TableColumn<Tour, String> colDescription; 
    @FXML public TableColumn<Tour, String> colDeparture;   
    @FXML public TableColumn<Tour, Double> colPrice;
    @FXML public TableColumn<Tour, Integer> colCapacity;
    @FXML public TableColumn<Tour, String> colStart;
    @FXML public TableColumn<Tour, String> colEnd;
    @FXML public TableColumn<Tour, String> colStatus;      
    
    @FXML public TextField txtSearch; // Ô tìm kiếm

    public ObservableList<Tour> tourList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        colId.setCellValueFactory(new PropertyValueFactory<>("tourID"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        colDeparture.setCellValueFactory(new PropertyValueFactory<>("departurePoint"));
        colPrice.setCellValueFactory(new PropertyValueFactory<>("pricePerPerson"));
        colCapacity.setCellValueFactory(new PropertyValueFactory<>("maxPeople"));
        colStart.setCellValueFactory(new PropertyValueFactory<>("startDate")); 
        colEnd.setCellValueFactory(new PropertyValueFactory<>("endDate"));     
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        colPrice.setCellFactory(tc -> new TableCell<Tour, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("%,.0f VNĐ", price));
                }
            }
        });
  
        colStatus.setCellFactory(tc -> new TableCell<Tour, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item);
                    if (item.equals("Đang diễn ra")) {
                        setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
                    } else if (item.equals("Đã kết thúc")) {
                        setStyle("-fx-text-fill: red;");
                    } else {
                        setStyle("-fx-text-fill: blue;"); 
                    }
                }
            }
        });

        loadData();
        setupSearch();
    }

    // Hàm đọc dữ liệu từ file và đổ vào bảng
    public void loadData() {
        tourList.clear();
        tourList.addAll(TourRepository.loadToursFromFile());
        tourTable.setItems(tourList);
        tourTable.refresh();
    }

    // Cấu hình chức năng tìm kiếm 
    public void setupSearch() {
        FilteredList<Tour> filteredData = new FilteredList<>(tourList, p -> true);

        // Lắng nghe thay đổi trong ô tìm kiếm
        txtSearch.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(tour -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true; // Hiện tất cả nếu ô tìm kiếm rỗng
                }
                String lowerCaseFilter = newValue.toLowerCase();

                // Kiểm tra ID, Mô tả hoặc Điểm đi có chứa từ khóa không
                if (tour.getTourID().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                } else if (tour.getDescription().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                } else if (tour.getDeparturePoint().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                }
                return false;
            });
        });
        tourTable.setItems(filteredData); // Gắn danh sách đã lọc vào bảng
    }

    @FXML
    public void handleAdd(ActionEvent event) {
        openDialog(null); 
    }

    @FXML
    public void handleEdit(ActionEvent event) {
        Tour selected = tourTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            openDialog(selected); 
        } else {
            showAlert(Alert.AlertType.WARNING, "Chưa chọn Tour", "Vui lòng chọn tour cần sửa!");
        }
    }

    // Hàm mở cửa sổ Popup 
    public void openDialog(Tour tour) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/TourDialog.fxml"));
            Parent root = loader.load();

            // Lấy controller của popup để truyền dữ liệu
            TourDialogController service = loader.getController();
            if (tour != null) {
                service.setEditData(tour); 
            }

            Stage stage = new Stage();
            stage.setTitle(tour == null ? "Thêm Tour Mới" : "Cập Nhật Tour");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL); 
            stage.showAndWait(); 

            loadData(); 

        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Lỗi", "Không thể mở form: " + e.getMessage());
        }
    }
    
    public void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}