package controller;

import service.Accountservice;
import exception.InvalidPasswordException; 
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import model.Account;

// Controller xử lý giao diện Đổi Mật Khẩu cá nhân
public class ChangePasswordController {

    // --- Các thành phần giao diện FXML ---
    @FXML public PasswordField txtOldPass;     // Ô mật khẩu cũ
    @FXML public PasswordField txtNewPass;     // Ô mật khẩu mới
    @FXML public PasswordField txtConfirmPass; // Ô xác nhận mật khẩu mới
    @FXML public Label lblError;               // Nhãn hiển thị thông báo lỗi

    public Account currentAccount;  // Lưu thông tin tài khoản đang đăng nhập
    public Accountservice accountservice; 

    public ChangePasswordController() {
        this.accountservice = new Accountservice(); // Khởi tạo lớp xử lý nghiệp vụ
    }

    // Hàm nhận tài khoản từ màn hình chính truyền sang
    public void setCurrentAccount(Account account) {
        this.currentAccount = account;
    }

    // --- Xử lý sự kiện bấm nút Lưu (Đổi mật khẩu) ---
    @FXML
    void handleSave(ActionEvent event) {
        String oldPass = txtOldPass.getText();
        String newPass = txtNewPass.getText();
        String confirmPass = txtConfirmPass.getText();

        // 1. Kiểm tra nhập liệu trống
        if (oldPass.isEmpty() || newPass.isEmpty() || confirmPass.isEmpty()) {
            lblError.setText("Vui lòng nhập đầy đủ thông tin!");
            return;
        }

        // 2. Kiểm tra mật khẩu cũ người dùng nhập có đúng không
        if (!oldPass.equals(currentAccount.getPassword())) {
            lblError.setText("Mật khẩu cũ không chính xác!");
            return;
        }

        // 3. Kiểm tra mật khẩu mới và xác nhận có khớp nhau không
        if (!newPass.equals(confirmPass)) {
            lblError.setText("Mật khẩu xác nhận không khớp!");
            return;
        }

        // 4. Gọi Accountservice để xử lý logic nghiệp vụ và lưu file
        try {
            // Thực hiện đổi pass xuống tầng Service (Repository sẽ ghi file)
            accountservice.changeAccountPassword(currentAccount.getUsername(), newPass);
            
            // Nếu thành công: Cập nhật lại mật khẩu cho đối tượng hiện tại 
            currentAccount.setPassword(newPass);
            
            System.out.println("Đổi mật khẩu thành công: " + currentAccount.getUsername());
            closeDialog(); // Đóng cửa sổ
            
        } catch (InvalidPasswordException e) {
            // Bắt lỗi nghiệp vụ từ Service ném ra
            lblError.setText(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            lblError.setText("Lỗi hệ thống: " + e.getMessage());
        }
    }

    // --- Xử lý sự kiện nút Hủy ---
    @FXML
    void handleCancel(ActionEvent event) {
        closeDialog();
    }

    public void closeDialog() {
        Stage stage = (Stage) txtOldPass.getScene().getWindow();
        stage.close();
    }
}