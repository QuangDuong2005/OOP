package controller;

import java.io.IOException;

import service.Customerservice;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Customer;

// Controller quản lý màn hình danh sách Khách hàng
public class CustomerController {

    // --- Khai báo các cột và bảng trong FXML ---
    @FXML public TableView<Customer> customerTable;
    @FXML public TableColumn<Customer, String> colID;
    @FXML public TableColumn<Customer, String> colName;
    @FXML public TableColumn<Customer, String> colPhone;
    @FXML public TableColumn<Customer, String> colEmail;
    @FXML public TableColumn<Customer, String> colDob;

    public Customerservice customerservice;
    public ObservableList<Customer> customerList; 

    public void initialize() {
        customerservice = new Customerservice();
        customerList = FXCollections.observableArrayList();

        // 1. Cấu hình cột: Liên kết với tên thuộc tính trong Model
        colID.setCellValueFactory(new PropertyValueFactory<>("customerID")); 
        colName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colDob.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDateOfBirth()));

        customerTable.setItems(customerList);
        loadData(); 
    }

    // Hàm lấy dữ liệu từ Service và đổ vào bảng
    public void loadData() {
        customerList.clear();
        customerList.addAll(customerservice.getCustomers()); 
    }

    @FXML
    void handleRefresh(ActionEvent event) {
        loadData();
    }

    // --- Xử lý nút Thêm mới ---
    @FXML
    void handleAdd(ActionEvent event) {
        openDialog(null); 
    }

    // --- Xử lý nút Sửa ---
    @FXML
    void handleEdit(ActionEvent event) {
        Customer selected = customerTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Lỗi", "Vui lòng chọn khách hàng để sửa!");
            return;
        }
        openDialog(selected);
    }

    // --- Hàm mở cửa sổ Popup nhập liệu ---
    public void openDialog(Customer customer) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/CustomerDialog.fxml"));
            Parent root = loader.load();

            CustomerDialogController dialogservice = loader.getController();
            dialogservice.setCustomerservice(this.customerservice); 
            
            if (customer != null) {
                dialogservice.setEditData(customer);
            }

            Stage stage = new Stage();
            stage.setTitle(customer == null ? "Thêm Khách Hàng" : "Cập Nhật Thông Tin");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait(); 
            
            loadData(); 

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}