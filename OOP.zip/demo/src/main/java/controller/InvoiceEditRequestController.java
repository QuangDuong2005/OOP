package controller;

import service.Invoiceservice;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Account;
import model.Invoice;

// Controller xử lý Popup nhập liệu: Gửi yêu cầu sửa hóa đơn (cần Manager duyệt)
public class InvoiceEditRequestController {
    
    // --- Các control trên giao diện ---
    @FXML public Label lblInvoiceID;     // Hiển thị mã hóa đơn đang chọn
    @FXML public TextField txtNewAmount; // Ô nhập số tiền mới
    @FXML public TextArea txtReason;     // Ô nhập lý do sửa

    public Invoice selectedInvoice;
    public Account currentAccount; 
    public Invoiceservice invoiceservice = new Invoiceservice();

    public void setInvoiceInfo(Invoice invoice, Account account) {
        this.selectedInvoice = invoice;
        this.currentAccount = account;
        this.lblInvoiceID.setText(invoice.getInvoiceID());
    }

    // --- Xử lý sự kiện nút "Gửi Yêu Cầu" ---
    @FXML
    void handleSubmit() {
        try {
            String invID = selectedInvoice.getInvoiceID();
            double amount = Double.parseDouble(txtNewAmount.getText()); // Chuyển chuỗi sang số
            String reason = txtReason.getText();
            String staffID = currentAccount.getUsername(); // Lấy ID nhân viên gửi

            // Kiểm tra nhập liệu (Validate)
            if (reason.isEmpty()) {
                new Alert(Alert.AlertType.WARNING, "Vui lòng nhập lý do!").show();
                return;
            }

            invoiceservice.InvoiceEdit(invID, amount, reason, staffID);

            new Alert(Alert.AlertType.INFORMATION, "Đã gửi yêu cầu chỉnh sửa thành công!").showAndWait();
            handleCancel();
            
        } catch (NumberFormatException e) {
            // Bắt lỗi nếu người dùng nhập chữ vào ô số tiền
            new Alert(Alert.AlertType.ERROR, "Số tiền không hợp lệ!").show();
        }
    }

    // --- Xử lý nút Hủy ---
    @FXML
    void handleCancel() {
        ((Stage) lblInvoiceID.getScene().getWindow()).close();
    }
}