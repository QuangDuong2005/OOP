package controller;

import service.Tourservice;
import exception.DuplicateException;
import exception.InvalidDateException;
import exception.TourAlreadyBookedException;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Tour;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

// Controller xử lý Popup nhập liệu cho Tour (Thêm mới & Sửa)
public class TourDialogController implements Initializable {

    // --- Các ô nhập liệu trên form ---
    @FXML public TextField txtId;
    @FXML public TextArea txtDescription; 
    @FXML public TextField txtDeparture;
    @FXML public TextField txtPrice;
    @FXML public TextField txtCapacity;
    @FXML public DatePicker dpStart;
    @FXML public DatePicker dpEnd;
    
    @FXML public Button btnSave;
    @FXML public Button btnCancel;

    public Tourservice tourservice;
    public Tour currentTour;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        tourservice = new Tourservice();
    }

    // --- Hàm nhận dữ liệu từ màn hình danh sách (Chế độ Sửa) ---
    public void setEditData(Tour tour) {
        this.currentTour = tour;
        txtId.setText(tour.getTourID());
        txtId.setDisable(true); // Khóa ID (không được sửa khóa chính)
        
        txtDescription.setText(tour.getDescription());
        txtDeparture.setText(tour.getDeparturePoint());
        txtPrice.setText(String.valueOf(tour.getPricePerPerson())); 
        txtCapacity.setText(String.valueOf(tour.getMaxPeople()));
        if (tour.getStartDate() != null) dpStart.setValue(LocalDate.parse(tour.getStartDate()));
        if (tour.getEndDate() != null) dpEnd.setValue(LocalDate.parse(tour.getEndDate()));
        
        btnSave.setText("Cập nhật");
    }

    // --- Xử lý sự kiện nút Lưu ---
    @FXML
    public void handleSave() {
        //  Validate sơ bộ: Kiểm tra dữ liệu rỗng
        if (txtId.getText().isEmpty() || txtDescription.getText().isEmpty() || 
            dpStart.getValue() == null || dpEnd.getValue() == null) {
            showAlert(Alert.AlertType.ERROR, "Thiếu thông tin", "Vui lòng nhập đầy đủ thông tin.");
            return;
        }

        try {
            String id = txtId.getText().trim();
            String desc = txtDescription.getText().trim();
            String departure = txtDeparture.getText().trim();
            double price = Double.parseDouble(txtPrice.getText().trim());
            int maxPeople = Integer.parseInt(txtCapacity.getText().trim());
            String startDateStr = dpStart.getValue().toString();
            String endDateStr = dpEnd.getValue().toString();

            if (currentTour == null) {
                // --- TRƯỜNG HỢP THÊM MỚI (Create) ---
                tourservice.createTour(id, desc, departure, price, maxPeople, startDateStr, endDateStr); 
                
                showAlert(Alert.AlertType.INFORMATION, "Thành công", "Đã thêm tour mới.");
            } else {
                // --- TRƯỜNG HỢP CẬP NHẬT (Update) ---
                int bookedPeople = currentTour.getBookedPeople();
                
                tourservice.updateTourInfo(id, desc, departure, price, maxPeople, startDateStr, endDateStr, bookedPeople);
                
                showAlert(Alert.AlertType.INFORMATION, "Thành công", "Đã cập nhật tour.");
            }
            
            closeWindow(); 

        } catch (NumberFormatException e) {
            // Bắt lỗi nếu nhập chữ vào ô Giá/Số chỗ
            showAlert(Alert.AlertType.ERROR, "Lỗi nhập liệu", "Giá và Số chỗ phải là số.");
        } catch (DuplicateException | InvalidDateException | TourAlreadyBookedException e) {
            // Bắt các lỗi nghiệp vụ từ Service (Trùng ID, Ngày về trước ngày đi, Tour đã có khách...)
            showAlert(Alert.AlertType.ERROR, "Lỗi nghiệp vụ", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Lỗi hệ thống", e.getMessage());
        }
    }

    @FXML
    public void handleCancel() {
        closeWindow();
    }

    public void closeWindow() {
        Stage stage = (Stage) btnCancel.getScene().getWindow();
        stage.close();
    }

    public void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}