package controller;

import service.Bookingservice;
import exception.DuplicateException;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Booking;
import model.Customer; 
import model.Tour;
import repository.CustomerRepository;
import repository.TourRepository;
public class BookingDialogController {

    @FXML public TextField txtBookingID;
    @FXML public ComboBox<String> cbCustomerID; 
    @FXML public ComboBox<String> cbTourID;     
    @FXML public TextField txtNumPeople;
    @FXML public Label lblError;
    @FXML public Label lblTitle;

    public Bookingservice bookingservice;
    public boolean isEditMode = false;
    public String currentStaffID;
    
    public void setBookingservice(Bookingservice service) {
        this.bookingservice = service;
    }
    
    public void setCurrentStaffId(String id) {
        this.currentStaffID = id;
    }

    public void initialize() {
        List<Tour> tours = TourRepository.loadToursFromFile();
        for(Tour t : tours) {
            cbTourID.getItems().add(t.getTourID());
        }
        List<Customer> customers = CustomerRepository.loadCustomersFromFile();
        for(Customer t : customers) {
            cbCustomerID.getItems().add(t.getCustomerID());
        }
    }

    // Hàm gọi khi bấm nút Sửa: điền dữ liệu cũ vào form
    public void setEditData(Booking booking) {
        this.isEditMode = true;
        lblTitle.setText("CẬP NHẬT ĐƠN HÀNG");
        
        txtBookingID.setText(booking.getBookingID());
        txtBookingID.setDisable(true); // Không cho sửa ID
        
        cbCustomerID.setValue(booking.getCustomerID());
        cbCustomerID.setDisable(true); // Không đổi khách khi sửa
        
        cbTourID.setValue(booking.getTourID());
        cbTourID.setDisable(true); // Update số người trên tour cũ
        
        txtNumPeople.setText(String.valueOf(booking.getNumberOfPeople()));
    }

    @FXML
    void handleSave(ActionEvent event) {
        String bId = txtBookingID.getText().trim();
        String cId = cbCustomerID.getValue();
        String tId = cbTourID.getValue();
        String numStr = txtNumPeople.getText().trim();

        if (bId.isEmpty() || cId == null || tId == null || numStr.isEmpty()) {
            lblError.setText("Vui lòng nhập đủ thông tin!");
            return;
        }

        try {
            int numPeople = Integer.parseInt(numStr);

            if (isEditMode) {
                // Gọi hàm Update số lượng người
                bookingservice.updateBookingPeople(bId, tId, numPeople);
            } else {
                // Gọi hàm Tạo mới
                bookingservice.createBooking(bId, cId, tId, numPeople, currentStaffID);
            }
            
            closeDialog(); // Đóng cửa sổ sau khi lưu thành công
            
        } catch (NumberFormatException e) {
            lblError.setText("Số người phải là số nguyên!");
        } catch (DuplicateException e) {
            lblError.setText("Lỗi: " + e.getMessage());
        } catch (IllegalStateException | IllegalArgumentException e) {
            lblError.setText("Lỗi nghiệp vụ: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            lblError.setText("Lỗi hệ thống: " + e.getMessage());
        }
    }

    @FXML
    void handleCancel(ActionEvent event) {
        closeDialog();
    }

    public void closeDialog() {
        Stage stage = (Stage) txtBookingID.getScene().getWindow();
        stage.close();
    }
}