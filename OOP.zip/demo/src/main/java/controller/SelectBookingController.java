package controller;

import service.Invoiceservice;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Account;
import model.Booking;
import repository.BookingRepository;

// Controller xử lý Popup: Chọn Booking để thanh toán/tạo hóa đơn
public class SelectBookingController {
    @FXML public TableView<Booking> tblPendingBookings; // Bảng danh sách Booking chờ thanh toán
    @FXML public TableColumn<Booking, String> colBookingID, colCustomer;
    @FXML public TableColumn<Booking, Double> colPrice, colDebt;
    
    @FXML public TextField txtInvoiceID;   // Ô nhập mã hóa đơn
    @FXML public TextField txtPaidAmount;  // Ô nhập số tiền thanh toán
    @FXML public TextField txtNote;

    public Account currentAccount;
    public Invoiceservice invoiceservice = new Invoiceservice();

    // Nhận thông tin nhân viên đang tạo hóa đơn
    public void setAccount(Account account) {
        this.currentAccount = account;
    }

    @FXML
    public void initialize() {
        // 1. Cấu hình cột hiển thị dữ liệu
        colBookingID.setCellValueFactory(new PropertyValueFactory<>("bookingID"));
        colCustomer.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        colPrice.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));
        colDebt.setCellValueFactory(new PropertyValueFactory<>("debtAmount"));

        loadBookingData();
        
        // 2. Tiện ích: Tự động điền số tiền còn nợ vào ô "Số tiền trả" khi chọn dòng
        tblPendingBookings.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                txtPaidAmount.setText(String.valueOf(newVal.getDebtAmount()));
            }
        });
    }

    // Tải danh sách Booking hợp lệ (Chưa hủy và Còn nợ tiền)
    public void loadBookingData() {
        try {
            ObservableList<Booking> list = FXCollections.observableArrayList();
            for (Booking b : BookingRepository.loadBookingsFromFile()) {
                // Logic lọc: Không hủy AND Nợ > 0
                if (!b.getIsCancelled() && b.getDebtAmount() > 0) {
                    list.add(b);
                }
            }
            tblPendingBookings.setItems(list);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // --- Xử lý nút Xác nhận Tạo ---
    @FXML
    void confirmCreate() {
        Booking selected = tblPendingBookings.getSelectionModel().getSelectedItem();
        String invID = txtInvoiceID.getText().trim();
        String amountStr = txtPaidAmount.getText().trim();

        // 1. Kiểm tra nhập liệu (Validate)
        if (selected == null || invID.isEmpty() || amountStr.isEmpty()) {
            showAlert("Lỗi", "Vui lòng chọn Booking và nhập đầy đủ Mã HĐ, Số tiền!");
            return;
        }

        if (currentAccount == null) {
            showAlert("Lỗi", "Không xác định được nhân viên đang đăng nhập!");
            return;
        }

        try {
            double paidAmount = Double.parseDouble(amountStr);

            // 2. Gọi logic nghiệp vụ tạo hóa đơn từ Service
            invoiceservice.createInvoice(
                selected.getBookingID(), 
                paidAmount, 
                invID, 
                currentAccount.getUsername()
            );

            showAlert("Thành công", "Đã tạo hóa đơn " + invID + " cho Booking " + selected.getBookingID());
            handleCancel(); 

        } catch (NumberFormatException e) {
            showAlert("Lỗi", "Số tiền phải là một con số!");
        } catch (Exception e) {
            showAlert("Lỗi hệ thống", e.getMessage());
        }
    }

    // Đóng cửa sổ
    @FXML
    void handleCancel() {
        Stage stage = (Stage) tblPendingBookings.getScene().getWindow();
        stage.close();
    }

    public void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}