package controller;

import java.time.LocalDate;
import java.util.List;

import service.Reportservice;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Account;
import model.Booking;
import model.Invoice;
import model.Report;
import repository.BookingRepository;
import repository.InvoiceRepository;
import repository.ReportRepository;

// Controller quản lý màn hình Báo cáo Doanh thu
public class FinancialReportController {
    // --- Các thành phần giao diện ---
    @FXML public DatePicker dpFrom, dpTo; // Chọn khoảng thời gian
    @FXML public Label lblRevenue, lblInvoiceCount, lblBookingCount; // Hiển thị số liệu tổng hợp
    @FXML public TableView<Report> tblReports; // Bảng lịch sử các lần tạo báo cáo
    @FXML public TableColumn<Report, String> colId, colFrom, colTo;
    @FXML public TableColumn<Report, Double> colRevenue;

    public Account currentAccount; 
    public Report lastCreatedReport; // Lưu kết quả báo cáo vừa tạo (để dùng cho nút Xuất file)

    // Nhận thông tin User từ màn hình chính
    public void setAccount(Account account) {
        this.currentAccount = account;
    }

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("reportId"));
        colFrom.setCellValueFactory(new PropertyValueFactory<>("fromDate"));
        colTo.setCellValueFactory(new PropertyValueFactory<>("toDate"));
        colRevenue.setCellValueFactory(new PropertyValueFactory<>("totalRevenue"));
    
        dpFrom.setValue(LocalDate.now().withDayOfMonth(1));
        dpTo.setValue(LocalDate.now());
        
        refreshTable();
    }

    // --- Xử lý nút "Xem Báo Cáo" ---
    @FXML
    void handleGenerateReport() {
        if (currentAccount == null) {
            showAlert("Lỗi", "Không xác định được nhân viên đang đăng nhập!");
            return;
        }

        try {
            LocalDate from = dpFrom.getValue();
            LocalDate to = dpTo.getValue();
            
            // 3. Tải dữ liệu nguồn (Hóa đơn, Booking) từ file
            List<Invoice> invoices = InvoiceRepository.loadInvoicesFromFile();
            List<Booking> bookings = BookingRepository.loadBookingsFromFile();
            List<Report> cache = ReportRepository.loadFromFile();

            // 4. Gọi Service tính toán doanh thu & tạo báo cáo mới
            lastCreatedReport = Reportservice.createRevenueReport(from, to, currentAccount.getUsername(), invoices, bookings, cache);

            // 5. Cập nhật số liệu lên giao diện 
            lblRevenue.setText(String.format("%,.0f VNĐ", lastCreatedReport.getTotalRevenue()));
            lblInvoiceCount.setText(String.valueOf(lastCreatedReport.getTotalInvoices()));
            lblBookingCount.setText(String.valueOf(lastCreatedReport.getTotalBookings()));
            
            // 6. Làm mới bảng lịch sử
            refreshTable();
            showAlert("Thành công", "Đã tạo báo cáo doanh thu mới.");
            
        } catch (Exception e) {
            showAlert("Lỗi", e.getMessage());
        }
    }

    // --- Xử lý nút "Xuất File CSV" ---
    @FXML
    void handleExportCsv() {
        if (lastCreatedReport == null) {
            showAlert("Thông báo", "Vui lòng xem báo cáo trước khi xuất file!");
            return;
        }
        try {
            // Gọi Service để ghi kết quả báo cáo hiện tại ra file Excel/CSV
            List<Invoice> invoices = InvoiceRepository.loadInvoicesFromFile();
            Reportservice.exportReportToCsv(lastCreatedReport, invoices);
            showAlert("Thành công", "Báo cáo đã được xuất ra thư mục 'exports'");
        } catch (Exception e) {
            showAlert("Lỗi", "Không thể xuất file: " + e.getMessage());
        }
    }

    public void refreshTable() {
        tblReports.setItems(FXCollections.observableArrayList(ReportRepository.loadFromFile()));
    }

    public void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}