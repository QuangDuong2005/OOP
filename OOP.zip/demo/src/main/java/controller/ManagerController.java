package controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class ManagerController {

    @FXML
    public StackPane contentArea; // Mapping với fx:id="contentArea" bên FXML

    // --- CÁC HÀM XỬ LÝ MENU ---

    @FXML
    void showAccounts(ActionEvent event) {
        try {
            // Load file AccountView.fxml
            Parent view = FXMLLoader.load(getClass().getResource("/view/AccountView.fxml"));
            
            // Xóa nội dung cũ ở giữa và thêm nội dung mới vào
            contentArea.getChildren().clear();
            contentArea.getChildren().add(view);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void showEmployees(ActionEvent event) {
        try {
            // Load file AccountView.fxml
            Parent view = FXMLLoader.load(getClass().getResource("/view/EmployeeView.fxml"));
            
            // Xóa nội dung cũ ở giữa và thêm nội dung mới vào
            contentArea.getChildren().clear();
            contentArea.getChildren().add(view);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void showTours(ActionEvent event) {
        try {
            // Load file AccountView.fxml
            Parent view = FXMLLoader.load(getClass().getResource("/view/TourView.fxml"));
            
            // Xóa nội dung cũ ở giữa và thêm nội dung mới vào
            contentArea.getChildren().clear();
            contentArea.getChildren().add(view);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void showNotifications(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ApprovalView.fxml"));
            Parent root = loader.load();
           
            contentArea.getChildren().clear();
            contentArea.getChildren().add(root);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void showStatistics(ActionEvent event) {
        System.out.println("Click: Thống kê");
    }

    @FXML
    void handleLogout(ActionEvent event) throws IOException {
        // Quay về màn hình đăng nhập
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Login.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.centerOnScreen();
    }
}