package controller;

import java.io.IOException;

import service.Invoiceservice;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Account; 
import model.Invoice;
import repository.InvoiceRepository;

// Controller quản lý màn hình danh sách Hóa đơn
public class InvoiceListController {
    @FXML public TableView<Invoice> tblInvoices;
    @FXML public TableColumn<Invoice, String> colID, colBookingID, colDate, colStaff, colNote;
    @FXML public TableColumn<Invoice, Double> colAmount;

    public Invoiceservice invoiceservice = new Invoiceservice();
    public Account currentAccount; 

    // Hàm nhận thông tin tài khoản từ màn hình cha (AccountantController)
    public void setAccount(Account account) {
        this.currentAccount = account;
    }

    @FXML
    public void initialize() {
        colID.setCellValueFactory(new PropertyValueFactory<>("invoiceID"));
        colBookingID.setCellValueFactory(new PropertyValueFactory<>("bookingID"));
        colAmount.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("createdAt"));
        colStaff.setCellValueFactory(new PropertyValueFactory<>("createdByStaffId"));
        colNote.setCellValueFactory(new PropertyValueFactory<>("note"));

        loadData(); 
    }

    public void loadData() {
        // Lấy danh sách từ Repository và đổ vào bảng
        ObservableList<Invoice> data = FXCollections.observableArrayList(InvoiceRepository.loadInvoicesFromFile());
        tblInvoices.setItems(data);
    }

    // --- Xử lý nút "Yêu cầu sửa" ---
    @FXML
    void handleEditRequest() {
        Invoice selected = tblInvoices.getSelectionModel().getSelectedItem();
        if (selected == null) {
            new Alert(Alert.AlertType.WARNING, "Vui lòng chọn hóa đơn!").show();
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/InvoiceEditRequestView.fxml"));
            Parent root = loader.load();
            
            // Lấy controller của popup để truyền dữ liệu
            InvoiceEditRequestController service = loader.getController();
            // Truyền hóa đơn cần sửa và thông tin người yêu cầu sang form sửa
            service.setInvoiceInfo(selected, this.currentAccount);

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Yêu cầu sửa hóa đơn");
            stage.setScene(new Scene(root));
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- Xử lý nút "Tạo hóa đơn" (Mở popup chọn Booking) ---
    @FXML
    void openCreateInvoicePopup(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/SelectBookingPopup.fxml"));
            Parent root = loader.load();
            
            SelectBookingController popupservice = loader.getController();
            
            if (this.currentAccount != null) {
                popupservice.setAccount(this.currentAccount);
            }

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Chọn Booking");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            
            loadData(); 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}