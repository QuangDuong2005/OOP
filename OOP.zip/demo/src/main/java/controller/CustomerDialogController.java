package controller;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import service.Customerservice;
import exception.DuplicateException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Customer;

// Controller điều khiển form nhập liệu (Thêm/Sửa khách hàng)
public class CustomerDialogController {

    // --- Các ô nhập liệu trên form ---
    @FXML public TextField txtID;
    @FXML public TextField txtName;
    @FXML public TextField txtPhone;
    @FXML public TextField txtEmail;
    @FXML public DatePicker dpDob;
    @FXML public Label lblTitle;   
    @FXML public Label lblError;   

    public Customerservice customerservice;
    public boolean isEditMode = false; 

    public void setCustomerservice(Customerservice service) {
        this.customerservice = service;
    }

    // --- Hàm nhận dữ liệu từ màn hình danh sách (Chế độ Sửa) ---
    public void setEditData(Customer customer) {
        isEditMode = true; 
        lblTitle.setText("CẬP NHẬT KHÁCH HÀNG");
        
        txtID.setText(customer.getCustomerID());
        txtID.setDisable(true); // Khóa ô ID, không cho phép sửa khóa chính
        
        txtName.setText(customer.getFullName());
        txtPhone.setText(customer.getPhoneNumber());
        txtEmail.setText(customer.getEmail());

        // --- SỬA 1: Parse ngày sinh ---
        try {
            String dobStr = customer.getDateOfBirth(); 
            if (dobStr != null && !dobStr.isEmpty()) {
                LocalDate date = LocalDate.parse(dobStr); 
                dpDob.setValue(date);
            }
        } catch (DateTimeParseException e) {
            System.err.println("Lỗi parse ngày cũ: " + e.getMessage());
            dpDob.setValue(null);
        }
        
    }

    // --- Xử lý sự kiện bấm nút Lưu ---
    @FXML
    void handleSave(ActionEvent event) {
        String id = txtID.getText().trim();
        String name = txtName.getText().trim();
        String phone = txtPhone.getText().trim();
        String email = txtEmail.getText().trim();
        
        // --- SỬA 2: Lấy ngày từ DatePicker ---
        LocalDate selectedDate = dpDob.getValue();
        String dob = "";
        
        if (selectedDate == null) {
            lblError.setText("Vui lòng chọn ngày sinh!");
            return;
        } else {
            dob = selectedDate.toString(); 
        }

        // 2. Validate dữ liệu (Kiểm tra rỗng)
        if (id.isEmpty() || name.isEmpty() || phone.isEmpty()) {
            lblError.setText("Vui lòng nhập ID, Tên và SĐT!");
            return;
        }

        // 3. Gọi Service để xử lý
        try {
            if (isEditMode) {
                // Trường hợp Update: Chỉ cập nhật thông tin, không sửa ID
                customerservice.updateCustomerInfo(id, name, phone, email);
            } else {
                // Trường hợp Create: Tạo mới hoàn toàn
                customerservice.createCustomer(id, name, dob, phone, email);
            }
            closeDialog(); 
            
        } catch (DuplicateException e) {
            lblError.setText("Lỗi: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            lblError.setText("Lỗi hệ thống: " + e.getMessage());
        }
    }

    @FXML
    void handleCancel(ActionEvent event) {
        closeDialog();
    }

    public void closeDialog() {
        Stage stage = (Stage) txtID.getScene().getWindow();
        stage.close();
    }
}