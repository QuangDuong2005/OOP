package controller;

import java.io.IOException;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Account;
import repository.AccountRepository;

// Controller quản lý màn hình danh sách tài khoản
public class AccountController {

    // --- Khai báo các thành phần giao diện ---
    @FXML
    public TableView<Account> userTable; // Bảng hiển thị danh sách
    @FXML
    public TableColumn<Account, String> colUsername; // Cột tên đăng nhập
    @FXML
    public TableColumn<Account, String> colOwnerID; 
    @FXML
    public TableColumn<Account, String> colRole; // Cột chức vụ
    @FXML
    public TableColumn<Account, Boolean> colStatus; // Cột trạng thái

    public ObservableList<Account> accountList = FXCollections.observableArrayList();

    // --- Hàm khởi chạy tự động khi giao diện được tải ---
    @FXML
    public void initialize() {
        colUsername.setCellValueFactory(new PropertyValueFactory<>("username"));
        colOwnerID.setCellValueFactory(new PropertyValueFactory<>("ownerID"));
        colRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("isActive")); 

        loadData();
    }

    // --- Hàm đọc dữ liệu từ file và đổ vào bảng ---
    @FXML
    void loadData() {
        accountList.clear(); // Xóa dữ liệu cũ trên giao diện
        List<Account> data = AccountRepository.loadAccountsFromFile(); // Đọc từ Repository
        accountList.addAll(data); // Thêm dữ liệu mới vào list
        userTable.setItems(accountList); // Gắn list vào bảng
    }

    // --- Xử lý sự kiện nút "Thêm mới" ---
    @FXML
    void handleAdd(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/CreateAccount.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Cấp tài khoản mới");
            stage.setScene(new Scene(root));
            
            // Hiển thị form thêm và chờ user đóng form này (để load lại dữ liệu mới)
            stage.showAndWait(); 
            
            loadData(); // Refresh lại bảng sau khi thêm xong
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- Xử lý sự kiện nút "Sửa" ---
    @FXML
    void handleEdit(ActionEvent event) {
        Account selected = userTable.getSelectionModel().getSelectedItem();
        
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Chưa chọn", "Vui lòng chọn tài khoản cần sửa.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/EditAccount.fxml"));
            Parent root = loader.load();

            // Lấy Controller của form sửa để truyền dữ liệu dòng đã chọn sang đó
            EditAccountController service = loader.getController();
            service.setEditData(selected);

            Stage stage = new Stage();
            stage.setTitle("Cập nhật tài khoản");
            stage.setScene(new Scene(root));
            stage.showAndWait();

            // Sau khi form đóng, load lại bảng để thấy thay đổi
            loadData(); 

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- Xử lý sự kiện nút "Xóa/Khóa" ---
    @FXML
    void handleDelete(ActionEvent event) {
        Account selected = userTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            // Validate: Không cho phép thao tác với tài khoản Manager
            if ((selected.getRole()).equals("Manager")){
                showAlert("Lỗi", "Bạn không thể sửa tải khoản của quản lý");
            }else{
                // Logic Soft Delete: Đảo ngược trạng thái Active (True <-> False)
                boolean newStatus = !selected.getIsActive(); 
                selected.setIsActive(newStatus); 
                
                // Lưu lại danh sách mới vào file JSON
                AccountRepository.saveAccountsToFile(accountList);
                
                // Refresh hiển thị trên bảng ngay lập tức
                userTable.refresh();
                showAlert("Thành công", "Đã khóa tài khoản: " + selected.getUsername());
            }
        } else {
            showAlert("Lỗi", "Vui lòng chọn tài khoản cần khóa!");
        }
    }

    // --- Các hàm tiện ích hiển thị thông báo ---
    public void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
    
    public void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    
}