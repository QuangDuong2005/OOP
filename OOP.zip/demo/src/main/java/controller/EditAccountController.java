package controller;

import java.net.URL;
import java.util.ResourceBundle;

import service.Accountservice;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Account;

// Controller quản lý màn hình Sửa thông tin tài khoản
public class EditAccountController implements Initializable {

    // --- Các thành phần giao diện FXML ---
    @FXML public TextField txtUsername;
    @FXML public ComboBox<String> cbRole;   // Chọn quyền hạn
    @FXML public ComboBox<String> cbStatus; // Chọn trạng thái (Active/Block)
    @FXML public TextField txtNewPass;      // Nhập mật khẩu mới (nếu muốn đổi)
    @FXML public Button btnSave;
    @FXML public Button btnCancel;

    public Accountservice accountservice;
    public Account currentAccount; 

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        accountservice = new Accountservice();
        cbRole.getItems().addAll("Manager", "Sale", "Accoutant");
        cbStatus.getItems().addAll("Hoạt động", "Đã khóa");
    }

    // --- Hàm nhận dữ liệu từ màn hình danh sách ---
    public void setEditData(Account account) {
        this.currentAccount = account;
        
        txtUsername.setText(account.getUsername());
        // Không cho sửa tên đăng nhập
        txtUsername.setDisable(true); 
        
        cbRole.setValue(account.getRole());
        if (account.getIsActive()) {
            cbStatus.setValue("Hoạt động");
        } else {
            cbStatus.setValue("Đã khóa");
        }
    }

    // --- Xử lý nút Lưu ---
    @FXML
    public void handleSave() {
        if (currentAccount == null) return;

        try {
            String username = currentAccount.getUsername();

            // 1. Xử lý đổi quyền (Role)
            String newRole = cbRole.getValue();
            // Chỉ gọi service nếu quyền thực sự thay đổi
            if (!newRole.equals(currentAccount.getRole())) {
                accountservice.updateAccountRole(username, newRole); 
            }

            // 2. Xử lý đổi trạng thái (Status)
            String newStatusStr = cbStatus.getValue();
            boolean newStatus = newStatusStr.equals("Hoạt động");
            
            // Chỉ gọi service nếu trạng thái thay đổi
            if (newStatus != currentAccount.getIsActive()) {
                if (newStatus) {
                    accountservice.activateAccount(username);
                } else {
                    accountservice.deactivateAccount(username);
                }
            }

            // 3. Xử lý đổi mật khẩu 
            // Chỉ đổi nếu người dùng nhập gì đó vào ô "Mật khẩu mới"
            String newPass = txtNewPass.getText().trim();
            if (!newPass.isEmpty()) {
                accountservice.changeAccountPassword(username, newPass);
            }

            showAlert(Alert.AlertType.INFORMATION, "Thành công", "Đã cập nhật tài khoản: " + username);
            closeWindow();

        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Lỗi cập nhật", e.getMessage());
        }
    }

    @FXML
    public void handleCancel() {
        closeWindow();
    }

    public void closeWindow() {
        Stage stage = (Stage) btnCancel.getScene().getWindow();
        stage.close();
    }

    public void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}