package controller;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Staff;
import repository.StaffRepository;

// Controller quản lý màn hình danh sách Nhân viên
public class EmployeeController implements Initializable {
    
    @FXML public TableView<Staff> employeeTable;
    @FXML public TableColumn<Staff, String> colId;
    @FXML public TableColumn<Staff, String> colName;
    @FXML public TableColumn<Staff, String> colRole; // Chức vụ
    @FXML public TableColumn<Staff, Boolean> colStatus; // Trạng thái

    public ObservableList<Staff> staffList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        colId.setCellValueFactory(new PropertyValueFactory<>("staffID")); 
        colName.setCellValueFactory(new PropertyValueFactory<>("fullName")); 
        colRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("isActive"));
        loadData();
    }

    /**
     * Hàm tải lại dữ liệu từ file/database lên bảng
     */
    public void loadData() {
        staffList.clear(); 
        List<Staff> data = StaffRepository.loadStaffsFromFile();
        if (data != null) {
            staffList.addAll(data);
        }
        employeeTable.setItems(staffList);
        employeeTable.refresh(); // Làm mới hiển thị
    }

    @FXML
    void handleAdd(ActionEvent event) {
        openDialog(null);
    }

    @FXML
    void handleEdit(ActionEvent event) {
        Staff selected = employeeTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            openDialog(selected);
        } else {
            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Vui lòng chọn nhân viên cần sửa!");
        }
    }

    // --- Xử lý nút Xóa/Khóa (Soft Delete) ---
    @FXML
    void handleDelete(ActionEvent event) {
        Staff selected = employeeTable.getSelectionModel().getSelectedItem();
        
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Chưa chọn nhân viên!");
            return;
        }

        // Xác định hành động dựa trên trạng thái hiện tại (Đang làm -> Cho nghỉ, Đã nghỉ -> Kích hoạt lại)
        String actionName = selected.getIsActive() ? "cho nghỉ việc" : "kích hoạt lại";
        
        // Hỏi xác nhận trước khi thực hiện
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Xác nhận");
        confirm.setHeaderText(null);
        confirm.setContentText("Bạn có chắc muốn " + actionName + " nhân viên " + selected.getFullName() + "?");
        
        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            // 1. Đảo ngược trạng thái hoạt động
            boolean newStatus = !selected.getIsActive();
            selected.setIsActive(newStatus);
            
            // 2. Cập nhật ngày nghỉ việc
            if (!newStatus) {
                selected.setEnDate(LocalDate.now().toString()); 
            } else {
                selected.setEnDate("null"); 
            }
            
            // 3. Lưu lại toàn bộ danh sách vào file JSON
            StaffRepository.saveStaffsToFile(staffList);
            
            // 4. Refresh lại bảng
            employeeTable.refresh();
            
            showAlert(Alert.AlertType.INFORMATION, "Thành công", "Đã cập nhật trạng thái nhân viên thành công.");
        }
    }

    /**
     * Hàm mở cửa sổ dialog (Dùng chung cho Thêm và Sửa)
     * @param staff Nếu null -> Thêm mới. Nếu có data -> Sửa.
     */
    public void openDialog(Staff staff) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/AddEmployee.fxml"));
            Parent root = loader.load();

            // Lấy controller của cửa sổ AddEmployee để truyền dữ liệu
            AddEmployeeController dialogservice = loader.getController();
            
            if (staff != null) {
                dialogservice.setEditData(staff); 
            }

            Stage stage = new Stage();
            stage.setTitle(staff == null ? "Thêm Nhân Viên Mới" : "Cập Nhật Thông Tin");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL); 
            stage.showAndWait();
            loadData();

        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Lỗi", "Không mở được form: " + e.getMessage());
        }
    }

    public void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.show();
    }
}