package controller;

import java.util.List;

import service.Approvalservice;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.ApprovalRequest;
import model.BookingCancelRequest;
import model.InvoiceEditRequest;
import repository.BookingCancelRequestRepository;
import repository.InvoiceEditRequestRepository;

// Controller quản lý màn hình Duyệt yêu cầu (Dành cho Quản lý)
public class ApprovalController {

    @FXML
    public TableView<ApprovalRequest> tableRequests; // Bảng chứa danh sách yêu cầu
    @FXML
    public TableColumn<ApprovalRequest, String> colId;
    @FXML
    public TableColumn<ApprovalRequest, String> colType; // Cột hiển thị loại yêu cầu (Sửa/Hủy)
    @FXML
    public TableColumn<ApprovalRequest, String> colStaff;
    @FXML
    public TableColumn<ApprovalRequest, String> colReason;
    @FXML
    public TableColumn<ApprovalRequest, String> colDetail; // Cột chi tiết (Số tiền/Hoàn tiền)
    @FXML
    public TableColumn<ApprovalRequest, String> colStatus;

    public Approvalservice approvalservice;
    
    public final String CURRENT_MANAGER_ID = "MGR001"; 

    public ApprovalController() {
        this.approvalservice = new Approvalservice(); // Khởi tạo Service logic
    }

    @FXML
    public void initialize() {
        setupColumns();
        loadData();
    }

    // --- Cấu hình hiển thị cho các cột trong bảng ---
    public void setupColumns() {
        // Các cột cơ bản ánh xạ trực tiếp từ thuộc tính class cha (ApprovalRequest)
        colId.setCellValueFactory(new PropertyValueFactory<>("requestId"));
        colStaff.setCellValueFactory(new PropertyValueFactory<>("staffId"));
        colReason.setCellValueFactory(new PropertyValueFactory<>("reason"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        // Cột Loại Yêu Cầu: Kiểm tra đối tượng thuộc Class con nào để hiển thị tên phù hợp
        colType.setCellValueFactory(cellData -> {
            ApprovalRequest req = cellData.getValue();
            if (req instanceof InvoiceEditRequest) {
                return new SimpleStringProperty("Sửa Hóa Đơn");
            } else if (req instanceof BookingCancelRequest) {
                return new SimpleStringProperty("Hủy Đặt Phòng");
            }
            return new SimpleStringProperty("Khác");
        });

        // Cột Chi tiết: Hiển thị thông tin riêng biệt tùy loại yêu cầu
        colDetail.setCellValueFactory(cellData -> {
            ApprovalRequest req = cellData.getValue();
            if (req instanceof InvoiceEditRequest) {
                // Nếu là sửa hóa đơn -> Hiển thị số tiền mới
                double amount = ((InvoiceEditRequest) req).getNewAmount();
                return new SimpleStringProperty("Mới: " + String.format("%,.0f", amount));
            } else if (req instanceof BookingCancelRequest) {
                // Nếu là hủy phòng -> Hiển thị số tiền hoàn trả
                BookingCancelRequest bcr = (BookingCancelRequest) req;
                return new SimpleStringProperty("Hoàn: " + String.format("%,.0f", bcr.getRefundAmount()));
            }
            return new SimpleStringProperty("-");
        });
    }

    @FXML
    public void handleRefresh() {
        loadData();
    }

    // --- Tải dữ liệu từ file và lọc danh sách ---
    public void loadData() {
        List<InvoiceEditRequest> invoiceReqs = InvoiceEditRequestRepository.loadFromFile();
        List<BookingCancelRequest> bookingReqs = BookingCancelRequestRepository.loadFromFile();

        ObservableList<ApprovalRequest> list = FXCollections.observableArrayList();
        
        // Chỉ thêm các yêu cầu đang ở trạng thái PENDING (Chờ duyệt) vào bảng
        for (InvoiceEditRequest r : invoiceReqs) {
            if ("PENDING".equalsIgnoreCase(r.getStatus())) list.add(r);
        }
        for (BookingCancelRequest r : bookingReqs) {
            if ("PENDING".equalsIgnoreCase(r.getStatus())) list.add(r);
        }

        tableRequests.setItems(list);
    }

    // --- Xử lý nút Duyệt (Approve) ---
    @FXML
    public void handleApprove() {
        ApprovalRequest selected = tableRequests.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Lỗi", "Vui lòng chọn một yêu cầu để duyệt.");
            return;
        }

        // Kiểm tra loại yêu cầu để gọi hàm xử lý tương ứng trong Service
        if (selected instanceof InvoiceEditRequest) {
            approvalservice.approveInvoiceEdit(selected.getRequestId(), CURRENT_MANAGER_ID);
        } else if (selected instanceof BookingCancelRequest) {
            approvalservice.approveBookingCancel(selected.getRequestId(), CURRENT_MANAGER_ID);
        }

        showAlert("Thành công", "Đã duyệt yêu cầu thành công!");
        loadData();
    }

    // --- Xử lý nút Từ chối (Reject) ---
    @FXML
    public void handleReject() {
        ApprovalRequest selected = tableRequests.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Lỗi", "Vui lòng chọn một yêu cầu để từ chối.");
            return;
        }

        boolean result = approvalservice.reject(selected.getRequestId(), CURRENT_MANAGER_ID, "Manager rejected via GUI");

        if (result) {
            showAlert("Thành công", "Đã từ chối yêu cầu.");
            loadData();
        } else {
            showAlert("Lỗi", "Không thể từ chối yêu cầu này.");
        }
    }

    public void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}