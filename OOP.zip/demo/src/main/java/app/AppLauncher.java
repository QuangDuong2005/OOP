package app;

public class AppLauncher {
    public static void main(String[] args) {
        // Gọi đến hàm main của file chính
        MainApp.main(args);
    }
}