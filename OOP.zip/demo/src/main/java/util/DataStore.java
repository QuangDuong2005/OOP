package util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashSet;
import java.util.Set;

public final class DataStore {
    public static final String DATA_DIR = "data";
    public static final Set<String> LOGGED = new HashSet<>();

    public DataStore() {}

    public static File getDataFile(String fileName) {
        try {
            Path dir = Path.of(System.getProperty("user.dir"), DATA_DIR);
            Files.createDirectories(dir);

            Path file = dir.resolve(fileName);
            if (!Files.exists(file)) {
                bootstrapFromResources(fileName, file);
            }
            if (LOGGED.add(fileName)) {
                System.out.println("[DataStore] Using: " + file.toAbsolutePath());
            }
            return file.toFile();
        } catch (IOException e) {
            return new File(DATA_DIR + File.separator + fileName);
        }
    }

    public static void bootstrapFromResources(String fileName, Path target) throws IOException {
        String resourcePath = "/data/" + fileName;
        try (InputStream in = DataStore.class.getResourceAsStream(resourcePath)) {
            if (in != null) {
                Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
                return;
            }
        }

        try (FileOutputStream out = new FileOutputStream(target.toFile())) {
            out.write("[]".getBytes());
        }
    }
}
