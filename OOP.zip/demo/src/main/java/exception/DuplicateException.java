package exception;

// Exception tùy chỉnh dùng để báo lỗi khi dữ liệu bị trùng lặp (VD: Trùng ID, Username...)
public class DuplicateException extends Exception {

    // Hàm khởi tạo nhận vào thông báo lỗi cụ thể
    public DuplicateException(String mess) {
        super(mess);
    }
    
}