package exception;
// lỗi khi cố sửa tour đã có người book
public class TourAlreadyBookedException extends Exception {
    public TourAlreadyBookedException(String mess){
        super(mess);
    }
}
